﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P0030482011004
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lbprova.Items.Clear();
            double[,] meses = new double[4, 4];
            double[] totaldomes = new double[4];
            double total = 0;
            for (int i = 0; i < 4; i++)
            {
                totaldomes[i] = 0;
                for (int j = 0; j < 4; j++)
                {
                    if (double.TryParse(Interaction.InputBox($"Mês " + (i + 1) + " Semana " + (j + 1)) , out meses[i, j]))
                    {
                    totaldomes[i] = totaldomes[i] + meses[i, j];
                    }
                    else
                    {
                        MessageBox.Show("Insira os Valores Numéricos");
                    }
                }
                total = totaldomes[i];
            }
            for(int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    lbprova.Items.Add($"Mês " + (i + 1) + " Semana " + (j + 1) + ":" + meses[i,j].ToString("c2"));
                    lbprova.Items.Add($"--------/--------");
                }
            }
            lbprova.Items.Add("O Total é : " + total.ToString("c2"));
        }
    }
}
