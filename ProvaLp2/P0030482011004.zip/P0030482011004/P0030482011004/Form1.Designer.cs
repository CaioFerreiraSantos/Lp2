﻿namespace P0030482011004
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbprova = new System.Windows.Forms.ListBox();
            this.verificar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbprova
            // 
            this.lbprova.FormattingEnabled = true;
            this.lbprova.Location = new System.Drawing.Point(241, 35);
            this.lbprova.Name = "lbprova";
            this.lbprova.Size = new System.Drawing.Size(210, 290);
            this.lbprova.TabIndex = 0;
            // 
            // verificar
            // 
            this.verificar.Location = new System.Drawing.Point(42, 142);
            this.verificar.Name = "verificar";
            this.verificar.Size = new System.Drawing.Size(130, 64);
            this.verificar.TabIndex = 1;
            this.verificar.Text = "Verificar";
            this.verificar.UseVisualStyleBackColor = true;
            this.verificar.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 363);
            this.Controls.Add(this.verificar);
            this.Controls.Add(this.lbprova);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lbprova;
        private System.Windows.Forms.Button verificar;
    }
}

